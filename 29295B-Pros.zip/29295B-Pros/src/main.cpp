#include "main.h"
#include "stdlib.h" //neccessary for std::[commands]
#include "sstream"  //neccessary for... logic
#include "math.h"   //neccessary for functions like abs() and round()
#include "string"   //neccessary for... using strings :sob:
#include "robot-config.h"



/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Hello PROS User!");

	pros::lcd::register_btn1_cb(on_center_button);

  //LDrive.
}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {}

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {


	while (true) {
	
	}
}

/*


#pragma region BoringVexConfigStuff

#include "robot-config.h"

//stupid fix to a bug in stdlib that prevents the concatonation of strings and other variable types
namespace patch { //instead of std::to_string([var]) its now patch::to_string([var])

    template < typename T > std::string to_string(const T & n)
    {
        std::ostringstream stm ;
        stm << n ;
        return stm.str();
    }
}




/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Clawbot Competition Template                              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// MainControl          controller
// Drivetrain           drivetrain    1, 10, D
// ClawMotor            motor         3
// ArmMotor             motor         8
// ---- END VEXCODE CONFIGURED DEVICES ----


// A global instance of competition


#pragma endregion

#pragma region NotesMaybeReadMe

// here to document weird quirks of V5, VSCode, or this particular program

/*
Sometimes things just break, like the abs() function was demanding 0 args. Restarting the program fixed this
Strings do not work in vex without external library shenanigans
*/

#pragma endregion

#pragma region Constants

float Pi = 3.14159265358;

#pragma endregion

#pragma region HelperFunctions //unit conversions and whatnot

/*
void PrintToController(std::string prefix, double data, int row, int column, bool clear) {

  if (clear) {
    MainControl.Screen.clearScreen();
  }  
  MainControl.Screen.setCursor(row, column);  
  MainControl.Screen.print(data);
  
}

void PrintToBrain(std::string prefix, double data, int row, int column, bool clear) {

  if (clear) {
    Brain.Screen.clearScreen();
  }  

  Brain.Screen.setCursor(row, column);  
  Brain.Screen.print(prefix.c_str());
  Brain.Screen.print(data);

}

// Math Functions
int absInt(int val) { // Convert integers to their absolute value
  return val < 0 ? -val : val;
}

double absDouble(double val) { // Convert integers to their absolute value
  return val < 0 ? -val : val;
}

float absFloat(float val) { // Convert integers to their absolute value
  return val < 0 ? -val : val;
}

int timerInPID;

#pragma endregion

///// Control Variables //////

bool twoStickMode = true; // toggles single or double stick drive
int deadband = 7;         // if the controller sticks are depressed less than deadband%, input will be ignored (to combat controller drift)
double RCTurnDamping = 0.65;

/////////////////////////////

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  LDrive.setPosition(0, deg);
  RDrive.setPosition(0, deg);
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

#pragma region AutonPID //the code behind the autonomous Proportional Integral Derivative controller

  #pragma region PIDVariables

  // control variables
  bool drivePIDIsEnabled = false;
  bool autonPIDIsEnabled = false;

  int desiredDistInDegrees = 200; // temporary
  int desiredHeading = 0;

  // tuning coefficients



*/



  //////       TUNING INSTRUCTIONS       //////
  /*
1. set all tuning values to 0
2. experiment with the P multiplier until you can drive a precise distance with slight oscilations at the end
3. experiment with the D multiplier until the oscilations slowly die out
4. experiment with the I multiplier until oscilations do not occur
*/


/*


  double lP = 1.0;
  double lI = 0.0;
  double lD = 0.0;

  double lOutput = 1.0;

  double rP = 1.0;
  double rI = 0.0;
  double rD = 0.0;

  double rOutput = 1.0;

  int integralBoundL = 10;
  int integralBoundR = 10;

  // Storage variables for Lateral (forward/back) PID

  double currentErrorL;      // reported value - desired value = position
  double previousErrorL = 0; // position from last loop
  double errorDerivativeL;   //(error - prevError)
  double errorIntegralL = 0;

  double lateralPower = 0;

  // Storage variables for Rotational (turning) PID

  double currentErrorR;      // reported value - desired value = position
  double previousErrorR = 0; // position from last loop
  double errorDerivativeR;   //(error - prevError)
  double errorIntegralR = 0;

  double rotationalPower = 0;

  // the second set of "turning" storage vars above are technically useless, as the code executes
  // in such a way that only one set of vars is needed to produce both outputs. however, readability is nice
  // change if memory ever becomes an issue

  #pragma endregion //end of PID variable declaration

void autonPID() {

  while (autonPIDIsEnabled)
  {

    ///////////////////////////////////////
    //////        Lateral PID        //////
    ///////////////////////////////////////

    int avgMotorPosition = (RDriveFrontM.position(deg) + LDriveFrontM.position(deg)) / 2;

    currentErrorL = lP * (desiredDistInDegrees - avgMotorPosition); // proportional error
    errorDerivativeL = lD * (currentErrorL - previousErrorL);       // derivative of error

    // filters out the integral at long ranges (if |error| < constant upper limit, eg. 10cm),
    // allowing it to be useful when needed without overpowering other elements

    if (absDouble(currentErrorL) < integralBoundL) { // NEED TO MAKE ABSOLUTE OF CURRENTERROR WORK
      errorIntegralL += lI * (currentErrorL);
    }
    else {
      errorIntegralL = 0;
    }

    lateralPower = (currentErrorL + errorDerivativeL + errorIntegralL) / lOutput;

    ///////////////////////////////////////
    //////      Rotational PID       //////
    ///////////////////////////////////////

    int avgBotRotation = LDriveFrontM.position(deg) - RDriveFrontM.position(deg);

    currentErrorR = rP * (desiredHeading - avgBotRotation);   // proportional error
    errorDerivativeR = rD * (currentErrorR - previousErrorR); // derivative of error

    // filters out the integral at long ranges (if |error| < constant upper value, eg. 10cm),
    // allowing it to be useful when needed without overpowering other elements

    if (absDouble(currentErrorR) < integralBoundR)
    { 
      errorIntegralR += rI * (currentErrorR);
    }
    else
    {
      errorIntegralR = 0;
    }

    rotationalPower = (currentErrorL + errorDerivativeL + errorIntegralL) / rOutput;

    ///////////////////////////////////////
    //////        ending math        //////
    ///////////////////////////////////////

    MainControl.Screen.setCursor(0, 0);
    MainControl.Screen.print("hi");

    timerInPID += 1;

    previousErrorL = currentErrorL;
    previousErrorR = currentErrorR;
    vex::task::sleep(20);
  }

  // return 1;
}

#pragma endregion // end of PID block

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma region ActualCompetitionFunctions

#pragma region AutonFunctions //Functions for autonomous control

// structure containing all neccessary data for an autonomous command
struct AutonCommand {
  double desiredDistInCM;
  double desiredHeading;

  double targetSpeed;
  int endDelay;
};

const int totalNumOfCommands = 10; // change depending on the total number of "steps" in your autonomous

// struct AutonCommands CommandList[totalNumOfCommands]; //initializes the list of autonomous commands, must be populated in active code (preauton)

void ExecuteAutonCommands(struct AutonCommand CurrentCommandList[]) {

  const double wheelCircumferance = (4.1875 * Pi) * 2.54;
  const double degPerCM = 360 / wheelCircumferance;

  // 360 degrees = circumferance cm

  for (int i = 0; ++i >= totalNumOfCommands;)
  {

    // PrintToController("Executing Step: " + i, 0, 0);

    struct AutonCommand CurrentCommand = CurrentCommandList[i];

    // setting the PID's target values for this stage of the autonomous routine
    desiredDistInDegrees = CurrentCommand.desiredDistInCM * degPerCM;
    desiredHeading = CurrentCommand.desiredHeading;

    double speedMult = CurrentCommand.targetSpeed / 100;

    // vex::task auton(autonPID);

    // RotPower is incorporated as a positive on the left side, meaning positive angles make righthand turns
    LDrive.spin(forward, speedMult * (lateralPower + rotationalPower), voltageUnits::volt);
    RDrive.spin(forward, speedMult * (lateralPower - rotationalPower), voltageUnits::volt);
  }
}

#pragma endregion // end of AutonFunctions

#pragma region UserControlFunctions

void UserControl() {

  Brain.Timer.reset();

  // if the controller is in 2 stick mode axis 4 is responsible for turning, axis 1 if not
  int turnAxisValue = twoStickMode ? MainControl.Axis1.position(percent) : MainControl.Axis4.position(percent);

  MainControl.Screen.clearScreen();
  MainControl.Screen.setCursor(0, 0);
  MainControl.Screen.print(MainControl.Axis3.position(percent));

  if (absInt(MainControl.Axis3.position(percent) + absInt(turnAxisValue) >= deadband))
  {

    double XAxisSpeed = MainControl.Axis3.position(percent);
    double turnSpeed = turnAxisValue * RCTurnDamping;

    LDrive.setVelocity(XAxisSpeed + turnSpeed, percent);
    RDrive.setVelocity(XAxisSpeed - turnSpeed, percent);
  }
}

#pragma endregion // end of UserControlFunctions

#pragma endregion // end of Bot controlling functions

#pragma region CodeExecution

void autonomous(void) {

  const double degPerCM = 360 / (4.1875 * Pi) * 2.54; // # of degrees per centimeter = 360 / (2Pir" * 2.54cm/")

  desiredDistInDegrees = 50 * degPerCM;
  desiredHeading = 0;

  // Prevent main from exiting with an infinite loop.
  while (true)
  {
    MainControl.Screen.setCursor(0, 0);

    // vex::task auton(autonPID);

    MainControl.Screen.print(lateralPower);

    LDrive.spin(forward, 0.75 * (lateralPower + rotationalPower), voltageUnits::volt);
    RDrive.spin(forward, 0.75 * (lateralPower - rotationalPower), voltageUnits::volt);

    wait(20, msec);
  }
}



*/



/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/



/*


int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(UserControl);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  const double degPerCM = 360 / (4.1875 * Pi) * 2.54; // # of degrees per centimeter = 360 / (2Pir" * 2.54cm/")

  desiredDistInDegrees = 50 * degPerCM;
  desiredHeading = 0;

  while (true) {
    wait(20, msec);
  }
}

#pragma endregion // closing the block with pre-auton / auton / driver control execution functions
*/